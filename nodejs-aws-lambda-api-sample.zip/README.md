# lambda_rest2soap
This is a sample lambda function (Node.js implementation) that when coupled with AWS API Gateway, could help to transform SOAP service calls into REST APIs.
The SOAP service used for this sample is available @ http://www.dneonline.com/calculator.asmx?wsdl

To install the dependencies referred in package.json file, use the following 'npm' command:
- npm install

>To know more about how to use this lambda please visit:
>https://adrin-mukherjee.medium.com/exposing-soap-service-as-rest-api-the-serverless-way-c3b565326cbd

